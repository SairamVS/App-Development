/**
 * 
 */
/**
 * @author Sairam V S
 *
 */
module Mini {
	requires java.sql;
}