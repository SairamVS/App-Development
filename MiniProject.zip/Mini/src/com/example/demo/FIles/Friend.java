package com.example.demo.FIles;

public class Friend extends User {
    public Friend(int id, String username, String email, int age) {
        super(id, username, email, age);
    }

    @Override
    public void printUserProfile() {
        System.out.println("Friend Profile:");
        System.out.println("ID: " + getId());
        System.out.println("Username: " + getUsername());
        System.out.println("Email: " + getEmail());
        System.out.println("Age: " + getAge());
        System.out.println();
    }
}
