package com.example.demo.FIles;

public interface Printable {
	void print();
}
