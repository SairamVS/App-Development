package com.example.demo.FIles;

import java.time.LocalDate;

public class premiumUser extends User {
    private int premiumId;
    private String subscriptionType;
    private LocalDate subscriptionExpiry;

    public premiumUser(int id, int premiumId, String username, String email, int age, String subscriptionType, LocalDate subscriptionExpiry) {
        super(id, username, email, age);
        this.premiumId = premiumId;
        this.subscriptionType = subscriptionType;
        this.subscriptionExpiry = subscriptionExpiry;
    }

    @Override
    public void printUserProfile() {
        System.out.println("Premium User Profile:");
        System.out.println("ID: " + getId());
        System.out.println("Username: " + getUsername());
        System.out.println("Email: " + getEmail());
        System.out.println("Age: " + getAge());
        System.out.println("Premium ID: " + premiumId);
        System.out.println("Subscription Type: " + subscriptionType);
        System.out.println("Subscription Expiry: " + subscriptionExpiry);
        System.out.println();
    }

	public int getPremiumId() {
		return premiumId;
	}

	public void setPremiumId(int premiumId) {
		this.premiumId = premiumId;
	}

	public String getSubscriptionType() {
		return subscriptionType;
	}

	public void setSubscriptionType(String subscriptionType) {
		this.subscriptionType = subscriptionType;
	}

	public LocalDate getSubscriptionExpiry() {
		return subscriptionExpiry;
	}

	public void setSubscriptionExpiry(LocalDate subscriptionExpiry) {
		this.subscriptionExpiry = subscriptionExpiry;
	}
}
