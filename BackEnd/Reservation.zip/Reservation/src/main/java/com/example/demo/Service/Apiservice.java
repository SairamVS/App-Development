package com.example.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Models.Reserve;
import com.example.demo.Repository.Apirepo;

@Service
public class Apiservice {
	@Autowired
	private Apirepo repo;
	
	public String addTable(Reserve re) 
	{
		repo.save(re);
		return "Added";
	}
	public List<Reserve> getTable()
	{
		return (List<Reserve>) repo.findAll();
	}
	
	public String updateTable(Reserve re)
	{
		repo.save(re);
		return "Update";
	}
	
	public void deleteById(int id)
	{
		repo.deleteById(id);
	}
	

}
