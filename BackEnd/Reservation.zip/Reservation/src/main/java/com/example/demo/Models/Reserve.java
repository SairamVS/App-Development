package com.example.demo.Models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Reserve {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	private String Username;
	
	private String Email;
	
	private String date;
	
	private String Time;
	
	private int No_of_Members;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return Username;
	}

	public void setUsername(String username) {
		Username = username;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTime() {
		return Time;
	}

	public void setTime(String time) {
		Time = time;
	}

	public int getNo_of_Members() {
		return No_of_Members;
	}

	public void setNo_of_Members(int no_of_Members) {
		No_of_Members = no_of_Members;
	}

	public Reserve(int id, String username, String email, String date, String time, int no_of_Members) {
		super();
		this.id = id;
		Username = username;
		Email = email;
		this.date = date;
		Time = time;
		No_of_Members = no_of_Members;
	}
	
}
