package com.example.demo.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class User {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	private String Username;
	
	private String Email;
	
	private String Gender;
	
	private Long Phone_No;

	public User(int id, String username, String email, String gender, Long phone_No) {
		super();
		this.id = id;
		Username = username;
		Email = email;
		Gender = gender;
		Phone_No = phone_No;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return Username;
	}

	public void setUsername(String username) {
		Username = username;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public Long getPhone_No() {
		return Phone_No;
	}

	public void setPhone_No(Long phone_No) {
		Phone_No = phone_No;
	}
	
	public User() {
		
	} 
}
