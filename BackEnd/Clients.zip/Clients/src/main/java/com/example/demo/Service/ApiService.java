package com.example.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.User;
import com.example.demo.Repository.ApiRepo;

@Service
public class ApiService {
	
	@Autowired
	private ApiRepo repo;
	
	public String addUser(User u) 
	{
		repo.save(u);
		return "Added";
	}
	public List<User> getUser()
	{
		return (List<User>) repo.findAll();
	}
	
	public String updateUser(int id,User u)
	{
		repo.saveAndFlush(u);
		return "Update";
	}
	
	public void deleteById(int id)
	{
		repo.deleteById(id);
	}
	

}
