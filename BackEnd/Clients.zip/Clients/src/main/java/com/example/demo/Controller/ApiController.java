package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.User;
import com.example.demo.Service.ApiService;

@RestController
public class ApiController {
	
	@Autowired
	private ApiService serv;
	
	@PostMapping("/add")
	public String add(@RequestBody User u)
	{
		return serv.addUser(u);
	}
	
	@GetMapping("/get")
	public List<User> get()
	{
		return serv.getUser();
	}
	
	@PutMapping("/update/{id}")
	public String updte(@PathVariable int id,@RequestBody User u)
	{
		return serv.updateUser(id,u);
	}
	
	@DeleteMapping("/delete/{id}")
	public String delete(@PathVariable int id)
	{
		serv.deleteById(id);
		return "Deleted Successfully";
	}

}
