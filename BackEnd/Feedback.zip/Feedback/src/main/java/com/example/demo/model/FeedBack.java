package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
@Entity
public class FeedBack {
	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	private long id;
	private String Name;
	private String Email;
	private String Restaurant_Name;
	private String Feedback;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getRestaurant_Name() {
		return Restaurant_Name;
	}
	public void setRestaurant_Name(String restaurant_Name) {
		Restaurant_Name = restaurant_Name;
	}
	public String getFeedback() {
		return Feedback;
	}
	public void setFeedback(String feedback) {
		Feedback = feedback;
	}
	public FeedBack(long id, String name, String email, String restaurant_Name, String feedback) {
		super();
		this.id = id;
		Name = name;
		Email = email;
		Restaurant_Name = restaurant_Name;
		Feedback = feedback;
	}
	
	public FeedBack() {
		
	}
}
