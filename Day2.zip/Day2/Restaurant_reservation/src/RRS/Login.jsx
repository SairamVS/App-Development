import React,{ Component } from "react";
import './Login.css';
import { Link } from "react-router-dom";

class Login extends Component{
    constructor(props){
        super(props);
        this.state = {Username: '',Password:''};
    }

    handleuName = (eve) => {
        this.setState({Username: eve.target.value});
    };

    handlePass = (eve) => { 
        this.setState({Password: eve.target.value});
    };

    handleSubmit = (eve) => {
        eve.prevantDefault();

        console.log('Username : ', this.state.Username);
        console.log('Password : ',this.state.Password);

        this.setState({Username:'',Password:''});
    };

    render(){
        const{ Username,Password } = this.state;

        return(
            <form className='form' onSubmit={this.handleSubmit}>
                <h2 className="head">Login Form</h2>
                <div className='name'>
                    <label className="uName">Username : </label>
                    <input className='in' type="text" placeholder="Enter your Username" onChange={this.handleuName}></input>
                </div>
                <div className='pass'>
                    <label className="uPass">Password : </label>
                    <input className="in2" type="password" placeholder="Enter Your Password" onChange={this.handlePass}></input>
                </div>
                <div>
                    <button className="btn" type="submit">Log In</button>
                    <p>Don't have an account?<Link to='/Register'>Register</Link>
                </p>
                </div>
            </form>

        );
    }
}

export default Login;