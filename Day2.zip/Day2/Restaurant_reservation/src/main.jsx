import React from 'react'
import ReactDOM from 'react-dom/client'
import App1 from './RRS/Login';
import App from './RRS/App1';
import './index.css'
import { BrowserRouter } from 'react-router-dom';

ReactDOM.createRoot(document.getElementById('root')).render(
  <BrowserRouter>
    <App/>
  </BrowserRouter>,
)
